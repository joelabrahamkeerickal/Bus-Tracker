<?php
include 'dbConfig.php';

if(isset($_POST['importSubmit'])){

    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
        if(is_uploaded_file($_FILES['file']['tmp_name'])){

            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');

            fgetcsv($csvFile);
			//parsing
			$mysql_tb = 'routes';

            while(($line = fgetcsv($csvFile)) !== FALSE){		
                
                    $db->query("INSERT INTO `".$mysql_tb."` (lat, lon, time_from, time_to, status) VALUES ('".$line[0]."','".$line[1]."','".$line[2]."','".$line[3]."','".$line[4]."')");
                
            }
            fclose($csvFile);

            $qstring = '?status=succ';
        }else{
            $qstring = '?status=err';		//for error in database operations
        }
    }else{
        $qstring = '?status=invalid_file';		//for errors in file format
    }
}
header("Location: route.php".$qstring);

?>