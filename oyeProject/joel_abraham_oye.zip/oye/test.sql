-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2017 at 08:47 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `email`, `phone`, `created`, `status`) VALUES
(1, 'Joel Abraham', 'joel@gmail.com', '1234567', '2017-06-22 12:12:00', '1'),
(2, 'Tim', 'asdf@sdf.com', '8765432', '2017-07-20 14:12:30', '0'),
(3, 'Ron', 'jhgfdsa@asdfgh.com', '9345678', '2017-07-22 10:12:00', '1'),
(4, 'Shawn', 'Asdfg@1234.com', '7654345', '2017-07-23 14:12:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` int(11) NOT NULL,
  `lat` float NOT NULL,
  `lon` float NOT NULL,
  `time_from` time NOT NULL,
  `time_to` time NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `lat`, `lon`, `time_from`, `time_to`, `status`) VALUES
(1, 70.5423, 71.2345, '10:30:00', '10:45:00', '1'),
(2, 68.5543, 65.6789, '15:30:00', '17:00:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `route_contacts`
--

CREATE TABLE `route_contacts` (
  `id` int(11) NOT NULL,
  `primary_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `primary_number` int(15) NOT NULL,
  `name_1` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `number_1` int(15) NOT NULL,
  `name_2` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `number_2` int(15) NOT NULL,
  `stop_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `route_contacts`
--

INSERT INTO `route_contacts` (`id`, `primary_name`, `primary_number`, `name_1`, `number_1`, `name_2`, `number_2`, `stop_name`, `status`) VALUES
(1, 'Tom', 765432345, 'Jim', 987654567, 'Sam', 456787654, 'xyz', '0'),
(2, 'Ron', 234567876, 'Don', 987654345, 'Alex', 765432345, 'abc', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `route_contacts`
--
ALTER TABLE `route_contacts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `route_contacts`
--
ALTER TABLE `route_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
